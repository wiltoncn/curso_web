<?php 
	require_once('../webservices/nusoap-master/src/nusoap.php');

	$inputJSON = file_get_contents('php://input');
    $input = json_decode($inputJSON, true);


	$user		= !empty($input['user']) 	? $input['user'] 	: 'wilton_874@hotmail.com';
	$pass 		= !empty($input['pass']) 	? $input['pass'] 	: '123456';
	$array = array();
	
	$Client_Login = new nusoap_client("http://localhost/curso_web/webservices/webservices.php?wsdl", true);

	$result = $Client_Login->call("Login",  array("P1" => $user, "P2" => $pass));
    $arrayBusPers = $result;

	//echo "Contador: ".count($arrayBusPers)."<br>";

	$contador = count($arrayBusPers);

	if($contador==0){
	$array["data"][] = array("contador" => $contador);
	}

	for($i=0;$i<$contador;$i++){
		$array["data"][] = array("contador" => $contador);
	}

	echo json_encode($array);
?>