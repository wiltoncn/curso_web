<?php
                require_once('nusoap-master/src/nusoap.php'); 	// php8
				include_once("../conexion/conexion_BD.php");
                include_once("../funciones/func_search.php");

                $server = new soap_server();
                $server -> configureWSDL('WEB SERVICES BD EMPRESA - DESARROLLADO POR WILTON CARDOZA NAVARRO.', 'urn:MyServicewsdl');
                //Character encoding.
	            $server->soap_defencoding = 'UTF-8';

				//-------------------------------------------------------------------------
				$server->wsdl->addComplexType( 
				'ArregloLogin',         // Nombre.
				'complexType',          // Tipo de Clase.
				'array',                // Tipo de PHP.
				'',                     // definición del tipo secuencia(all|sequence|choice).
				'SOAP-ENC:Array',       // Restricted Base.
				array(), 
				array(array('ref' => 'SOAP-ENC:arrayType', 'wsdl:arrayType' => 'tns:BuscarLoginUser[]')),
				'tns:BuscarLoginUser'
				);
				 
				$server->wsdl->addComplexType(
				'BuscarLoginUser',
				'complexType',
				'struct',
				'all',
				'',
				array(
				'Correo_Eletronico' => array('name' => 'Correo_Eletronico','type' => 'xsd:string'),
				'Clave' => array('name' => 'Clave', 'type' => 'xsd:string')
				)
				);
				
				$server->register(
				'Login',                                    // Nombre del Metodo.
				array('P1' => 'xsd:string',
				      'P2' => 'xsd:string'),                // Parametros de Entrada.
				array('return' => 'tns:ArregloLogin')       // Datos de Salida.
				);

				//Body BuscarUsuarios function.
				function Login($p1, $p2){
				$objTablasPersonal = new _Query();
                		$fila_Pers_1 = $objTablasPersonal -> _Buscar_Correo_Clave_PDO($p1, $p2);

				$datos = array();
				while($reg_1 = $fila_Pers_1 -> fetch(PDO::FETCH_ASSOC)){
				$datos[] = array('Correo_Eletronico' => $reg_1['Correo_Eletronico'],
								'Clave' => $reg_1['Clave']);
				}
				return $datos;
				}
				//-----------------------------------------------------------------------
		$server->service(file_get_contents("php://input"));
?>