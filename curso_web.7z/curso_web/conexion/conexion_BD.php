<?php

/***************Inicio PDO*******************/
$Host = "localhost";
$BD   = "bd_empresa";
$User = "root";
$Pass = "%at3nt0%";
/***************Fin PDO*******************/

class Cnn{
public $Host;
public $BD;
public $User;
public $Pass;
static  $instanceBD;

public $cCnn;
public $rs;

public function __construct(){ //private
       global $Host, $BD, $User, $Pass;
	   $this -> Host = $Host;
	   $this -> BD   = $BD;
	   $this -> User = $User;
	   $this -> Pass = $Pass;
}
public static function getInstanceBD(){
       if(!(self::$instanceBD instanceof self)){ 
         		self::$instanceBD = new self(); 
       } 
       return self::$instanceBD; 
} 
public function getHost(){
       return $this -> Host;
}
public function getBD(){
       return $this -> BD;
}
public function getUser(){
       return $this -> User;
}
public function getPass(){
       return $this -> Pass;
}
}

class clsCnn_PDO extends Cnn{

public function clsCnn_PDO(){
       $this -> setConexion();
       $this -> AbrirConexion();
}
public function setConexion(){ //private
      	$Cnn = Cnn::getInstanceBD();
      	$this -> Host = $Cnn -> getHost();
      	$this -> BD   = $Cnn -> getBD();
      	$this -> User = $Cnn -> getUser();
      	$this -> Pass = $Cnn -> getPass();
}  
public function __destruct(){
  	   if(isset($this -> cCnn)){
		unset($this -> cCnn);	
	   }
}
public function CerrarConexion(){	
  	   $this -> cCnn = null;
}
public function AbrirConexion(){ //private
   		try{
			$this -> cCnn = new PDO('mysql:host='.$this -> Host.';dbname='.$this -> BD, $this -> User, $this -> Pass);
			//echo "Conexion Exito";
		}catch(Exception $e){
			$error = die("Error De Conexion :<br />".$e -> getMessage().'<br/>'."\n");
			echo $error;
		}
}

function Sql_PDO($sql){
	$this -> AbrirConexion();
	$args = func_get_args();
       array_shift($args);
		$this -> rs = $this -> cCnn -> prepare($sql);
		$this -> rs -> execute($args) or die("Error Query Mysql.");
		if($this -> rs == true){
		    return $this -> rs;
		}
		$this -> rs = null;
	$this->CerrarConexion();
}
}
?>