<?php
class _Query{
public $cCnn;

public function _Query(){
        $this -> cCnn = new clsCnn_PDO();
}

function _Buscar_Correo_Clave_PDO($p1, $p2){
	$this -> _Query();
        $cons = "CALL sql_login('".$p1."', '".$p2."');";
		$rs = $this -> cCnn -> Sql_PDO($cons);
		if(!$rs){
		return false;
		}else{
		return $rs;
		}
}
}
?>